import math


class CalculadoraTrigonometrica:

    def __init__(self):
        self.angulo = 0
        self.resultado = 0

    def seno(self):
        self.angulo = float(input("Ingrese el angulo en grados: "))

        radianes = self.angulo * math.pi / 180

        self.resultado = math.sin(radianes)

        print("Seno:", self.resultado)

    def coseno(self):
        self.angulo = float(input("Ingrese el angulo en grados: "))

        radianes = self.angulo * math.pi / 180

        self.resultado = math.cos(radianes)

        print("Coseno:", self.resultado)

    def tangente(self):
        self.angulo = float(input("Ingrese el angulo en grados: "))

        radianes = self.angulo * math.pi / 180

        if math.cos(radianes) == 0:
            print("Error: la tangente no existe para este angulo")
        else:
            self.resultado = math.tan(radianes)

            print("Tangente:", self.resultado)

    def menu(self):

        while True:

            print("\n--- CALCULADORA TRIGONOMETRICA ---")
            print("1. Seno")
            print("2. Coseno")
            print("3. Tangente")
            print("4. Salir")

            opcion = input("Seleccione una opcion: ")

            if opcion == "1":
                self.seno()

            elif opcion == "2":
                self.coseno()

            elif opcion == "3":
                self.tangente()

            elif opcion == "4":
                break

            else:
                print("Opcion incorrecta")