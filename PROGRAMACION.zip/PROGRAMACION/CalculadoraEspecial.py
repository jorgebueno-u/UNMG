class CalculadoraEspecial:

    def __init__(self):
        self.numero1 = 0
        self.numero2 = 0
        self.resultado = 0

    def raiz(self):

        self.numero1 = float(input("Ingrese el numero: "))
        self.numero2 = int(input("Ingrese el indice de la raiz: "))

        if self.numero2 <= 0:
            print("Error: el indice debe ser mayor que cero")

        elif self.numero1 < 0 and self.numero2 % 2 == 0:
            print("Error: no existe una raiz par real de un numero negativo")

        else:

            if self.numero1 < 0:
                self.resultado = -((-self.numero1) ** (1 / self.numero2))
            else:
                self.resultado = self.numero1 ** (1 / self.numero2)

            print("Resultado:", self.resultado)

    def potencia(self):

        self.numero1 = float(input("Ingrese la base: "))
        self.numero2 = float(input("Ingrese el exponente: "))

        if self.numero1 < 0 and self.numero2 != int(self.numero2):
            print("Error: el resultado seria imaginario")

        else:
            self.resultado = self.numero1 ** self.numero2

            print("Resultado:", self.resultado)

    def factorial(self):

        self.numero1 = int(input("Ingrese un numero entero: "))

        if self.numero1 < 0:

            print("Error: no existen factoriales de numeros negativos")

        else:

            self.resultado = 1

            for i in range(1, self.numero1 + 1):
                self.resultado = self.resultado * i

            print("Factorial:", self.resultado)

    def fibonacci(self):

        self.numero1 = int(input("Ingrese la posicion de Fibonacci: "))

        if self.numero1 < 0:

            print("Error: la posicion no puede ser negativa")

        else:

            a = 0
            b = 1

            for i in range(self.numero1):
                siguiente = a + b
                a = b
                b = siguiente

            self.resultado = a

            print("Fibonacci:", self.resultado)

    def mcd(self):

        self.numero1 = int(input("Ingrese el primer numero: "))
        self.numero2 = int(input("Ingrese el segundo numero: "))

        a = abs(self.numero1)
        b = abs(self.numero2)

        while b != 0:
            residuo = a % b
            a = b
            b = residuo

        self.resultado = a

        print("MCD:", self.resultado)

    def mcm(self):

        self.numero1 = int(input("Ingrese el primer numero: "))
        self.numero2 = int(input("Ingrese el segundo numero: "))

        if self.numero1 == 0 or self.numero2 == 0:

            self.resultado = 0

        else:

            a = abs(self.numero1)
            b = abs(self.numero2)

            x = a
            y = b

            while y != 0:
                residuo = x % y
                x = y
                y = residuo

            mcd = x

            self.resultado = abs(self.numero1 * self.numero2) // mcd

        print("MCM:", self.resultado)

    def iva(self):

        precio = float(input("Ingrese el precio: "))
        porcentaje = float(input("Ingrese el porcentaje de IVA: "))

        if precio < 0 or porcentaje < 0:

            print("Error: los valores no pueden ser negativos")

        else:

            valor_iva = precio * porcentaje / 100

            self.resultado = precio + valor_iva

            print("Valor del IVA:", valor_iva)
            print("Precio con IVA:", self.resultado)

    def menu(self):

        while True:

            print("\n--- CALCULADORA ESPECIAL ---")
            print("1. Raiz enesima")
            print("2. Potencia enesima")
            print("3. Factorial")
            print("4. Fibonacci")
            print("5. Minimo comun multiplo")
            print("6. Maximo comun divisor")
            print("7. IVA")
            print("8. Salir")

            opcion = input("Seleccione una opcion: ")

            if opcion == "1":
                self.raiz()

            elif opcion == "2":
                self.potencia()

            elif opcion == "3":
                self.factorial()

            elif opcion == "4":
                self.fibonacci()

            elif opcion == "5":
                self.mcm()

            elif opcion == "6":
                self.mcd()

            elif opcion == "7":
                self.iva()

            elif opcion == "8":
                break

            else:
                print("Opcion incorrecta")