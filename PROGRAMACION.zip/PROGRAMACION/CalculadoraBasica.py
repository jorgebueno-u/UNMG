class CalculadoraBasica:

    def __init__(self):
        self.numero1 = 0
        self.numero2 = 0
        self.resultado = 0

    def suma(self):
        self.numero1 = float(input("Ingrese el primer numero: "))
        self.numero2 = float(input("Ingrese el segundo numero: "))

        self.resultado = self.numero1 + self.numero2

        print("Resultado:", self.resultado)

    def resta(self):
        self.numero1 = float(input("Ingrese el primer numero: "))
        self.numero2 = float(input("Ingrese el segundo numero: "))

        self.resultado = self.numero1 - self.numero2

        print("Resultado:", self.resultado)

    def multiplicacion(self):
        self.numero1 = float(input("Ingrese el primer numero: "))
        self.numero2 = float(input("Ingrese el segundo numero: "))

        self.resultado = self.numero1 * self.numero2

        print("Resultado:", self.resultado)

    def division(self):
        self.numero1 = float(input("Ingrese el primer numero: "))
        self.numero2 = float(input("Ingrese el segundo numero: "))

        if self.numero2 == 0:
            print("Error: no se puede dividir entre cero")
        else:
            self.resultado = self.numero1 / self.numero2
            print("Resultado:", self.resultado)

    def acumulativa(self):
        self.resultado = float(input("Ingrese el numero inicial: "))

        while True:

            print("\nResultado actual:", self.resultado)
            print("1. Sumar")
            print("2. Restar")
            print("3. Multiplicar")
            print("4. Dividir")
            print("5. Terminar")

            opcion = input("Seleccione una opcion: ")

            if opcion == "1":

                numero = float(input("Ingrese el numero: "))
                self.resultado = self.resultado + numero

            elif opcion == "2":

                numero = float(input("Ingrese el numero: "))
                self.resultado = self.resultado - numero

            elif opcion == "3":

                numero = float(input("Ingrese el numero: "))
                self.resultado = self.resultado * numero

            elif opcion == "4":

                numero = float(input("Ingrese el numero: "))

                if numero == 0:
                    print("Error: no se puede dividir entre cero")
                else:
                    self.resultado = self.resultado / numero

            elif opcion == "5":
                print("Resultado final:", self.resultado)
                break

            else:
                print("Opcion incorrecta")

    def menu(self):

        while True:

            print("\n--- CALCULADORA BASICA ---")
            print("1. Suma")
            print("2. Resta")
            print("3. Multiplicacion")
            print("4. Division")
            print("5. Calculadora acumulativa")
            print("6. Salir")

            opcion = input("Seleccione una opcion: ")

            if opcion == "1":
                self.suma()

            elif opcion == "2":
                self.resta()

            elif opcion == "3":
                self.multiplicacion()

            elif opcion == "4":
                self.division()

            elif opcion == "5":
                self.acumulativa()

            elif opcion == "6":
                break

            else:
                print("Opcion incorrecta")