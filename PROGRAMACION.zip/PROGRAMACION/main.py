from CalculadoraBasica import CalculadoraBasica
from CalculadoraTrigonometrica import CalculadoraTrigonometrica
from CalculadoraEspecial import CalculadoraEspecial


basica = CalculadoraBasica()
trigonometrica = CalculadoraTrigonometrica()
especial = CalculadoraEspecial()


while True:

    print("\n==============================")
    print("       CALCULADORA")
    print("==============================")
    print("1. Calculadora basica")
    print("2. Calculadora trigonometrica")
    print("3. Calculadora especial")
    print("4. Salir")
    print("==============================")

    opcion = input("Seleccione una calculadora: ")

    if opcion == "1":
        basica.menu()

    elif opcion == "2":
        trigonometrica.menu()

    elif opcion == "3":
        especial.menu()

    elif opcion == "4":
        print("Programa terminado")
        break

    else:
        print("Opcion incorrecta")